function setup() {
  createCanvas(500, 500);
  background(255, 204, 0);
  ellipse(250, 250, 50, 50);
}
