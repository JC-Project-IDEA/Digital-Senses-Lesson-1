function setup() {
  createCanvas(500, 500);
  background(0);
}

function draw() {
  ellipse(250,random(0,500),50,50);
}