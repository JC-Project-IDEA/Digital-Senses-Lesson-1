function setup() {
  createCanvas(500,500);
  background(0);
}
