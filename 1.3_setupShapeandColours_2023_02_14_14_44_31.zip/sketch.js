function setup() {
  createCanvas(500, 500);
  background(255, 204, 0);
  fill(255,0,0);
  ellipse(100,250,100,100);
  fill(0,255,0);
  rect(200,250,100,100);
  fill(0,0,255);
  rect(350,250,100,100,10);
}
