function setup() {
  createCanvas(500, 500);
  background(0);
}

function draw() {
  fill(random(0, 255),random(0, 255),random(0, 255));
  //我們也可以寫作
  // fill(random(255),random(255),random(255));
  ellipse(mouseX,mouseY,50,50);
}