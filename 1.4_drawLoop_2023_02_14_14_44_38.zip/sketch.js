function setup() {
  createCanvas(500, 500);
}

function draw() {
  background(255, 204, 0);
  ellipse(200,200,100,100);
  ellipse(mouseX,mouseY,100,100);
}